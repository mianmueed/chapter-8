package com.example.chapter8;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.text.Html;
import android.text.Spanned;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    EditText etMessage1, etMessage2;
    Integer[] arrayPointSize = {10,20,30,40,50};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        etMessage1 = findViewById(R.id.etMessage1);
        etMessage2 = findViewById(R.id.etMessage2);
        registerForContextMenu(etMessage1);
        registerForContextMenu(etMessage2);


    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
// only one Option menu per activity
        populateMyFirstMenu(menu);
        return super.onCreateOptionsMenu(menu);
    }
    @Override
    public boolean onPrepareOptionsMenu(Menu menu){
        //populateMyFirstMenu(menu);
        return super.onPrepareOptionsMenu(menu);
    }

    private void populateMyFirstMenu(Menu menu){
        int groupId = 0;
//arguments: groupId, optionId, order, title
        MenuItem item1 =menu.add(groupId, 1, 1, "10 points");
        MenuItem item2 =menu.add(groupId, 2, 2, "20 points");
        MenuItem item3 =menu.add(groupId, 3, 3, "30 points");
        MenuItem item4 =menu.add(groupId, 4, 4, "40 points");
        //menu.add(groupId, 5, 5, "50 points");
        menu.add(groupId, 6, 8, "Red text");
        menu.add(groupId, 7, 7, "Green Text");
        menu.add(groupId, 8, 6, "Blue text");

         item1.setIcon(R.drawable.france);
         item2.setIcon(R.drawable.germany);
         item3.setIcon(R.drawable.uk);
         item4.setIcon(R.drawable.us);

        item1.setShortcut('1','1');
        item2.setShortcut('2','2');
        item3.setShortcut('3','3');
        item4.setShortcut('4','4');
        int smGroupId = 0; // don't care, same as Menu.NONE
        int smItemId = 5; // fifth element
        int smOrder = 5; // don't care, same as Menu.NONE

        SubMenu subMenu = menu.addSubMenu(smGroupId,smItemId,smOrder,"Sub menu");
        subMenu.setHeaderIcon(R.drawable.uk);
        subMenu.setIcon(R.drawable.us);
        MenuItem sub51 = subMenu.add(smGroupId,5,1,"sub-menu 5-1");
        MenuItem sub52 = subMenu.add(smGroupId,5,2,"sub-menu 5-2");
        MenuItem sub53 = subMenu.add(smGroupId,5,3,"sub-menu 5-3");

    }
    public void onCreateContextMenu(ContextMenu menu, View v,
                                    ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);

        if (v.getId() == etMessage1.getId())
// create a menu for etMessage1 box
            populateMyFirstMenu(menu);
        if (v.getId() == etMessage2.getId()){
// create a menu for etMessage2 box
            populateMySecondMenu(menu);
        }
    }
    private void populateMySecondMenu(Menu menu){
        int groupId = 0;
//arguments: groupId, optionId, order, title
        menu.add(groupId, 9, 1, "Bold");
        menu.add(groupId, 10, 2, "Italic");
        menu.add(groupId, 11, 3, "Normal");
    }
    @Override
    public boolean onContextItemSelected(MenuItem item) {
        return(applyMenuOption(item) ||
                super.onContextItemSelected(item) );
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        return(applyMenuOption(item) ||
                super.onOptionsItemSelected(item) );

    }
    private boolean applyMenuOption(MenuItem item){
        int menuItemId = item.getItemId(); // 1, 2, 3, ...11
        String strMsg2 = etMessage2.getText().toString();
        if (menuItemId < 5) {
// first five option are for setting text size
            int newPointSize = arrayPointSize[menuItemId - 1];
            etMessage1.setTextSize(newPointSize);
            etMessage2.setTextSize(newPointSize);
        }
        else if (menuItemId == 5) {

            etMessage1.setText(
                    "You have selected: \n" + item.getTitle()
                            + "\nId: " + menuItemId
                            + " order: " + item.getOrder());
        }
        else {
// either change color on box text1 or style on text2
            if (menuItemId == 6)
                etMessage1.setTextColor(Color.RED);
//etMessage1.setTextColor(0xffff0000); // red
            else if (menuItemId == 7)

                etMessage1.setTextColor(0xff00ff00); // green
            else if (menuItemId == 8)
                etMessage1.setTextColor(0xff0000ff); // blue
            else if (menuItemId == 9)
                etMessage2.setText(beautify(strMsg2, "BOLD")); //bold
            else if (menuItemId == 10)
                etMessage2.setText(beautify(strMsg2, "ITALIC")); //italic
            else if (menuItemId == 11)
                etMessage2.setText(beautify(strMsg2, "NORMAL")); //normal
        }
        return false;
    }
    private Spanned beautify (String originalText, String selectedStyle){
        Spanned answer = null;
        if (selectedStyle.equals("BOLD"))
            answer = Html.fromHtml("<b>" + originalText +"</b");
        else if (selectedStyle.equals("ITALIC"))
            answer = Html.fromHtml("<i>" + originalText +"</i>");
        else if (selectedStyle.equals("NORMAL"))
            answer = Html.fromHtml("<normal>" + originalText +"</normal");
        return answer;
    }
}